package q1;

/**
 * @author Ryuta Toma
 * 1-100の数字を連続で出力する
 * ただし、3の倍数の時はFizz、5の倍数のときはBuzz、両方の条件を満たすときにはFizzBuzzとコンソールに表示するようにしなさい
 * なお、print文の利用は1度のみとする
 * */
public class FizzBuzzMain {
/*
 * @args メインメソッドの引数
 */
	public static void main(String[] args) {
		//1-100を繰り返す
		//割り切れるか判別し数字か文字列を出力する
		for(int i = 1; i < 101 ;i++) {
			//文字列の初期化
			String printWord ="";
			//3と5の両方で割れる場合、FizzBuuzを代入
			if(i % 3 == 0 && i % 5 == 0) {
				printWord = "FizzBuzz";
			}
			//3で割れる場合、Fizzzを代入
			else if(i % 3 == 0 ) {
				printWord = "Fizz";
			}
			//5で割れる場合、Buuzを代入
			else if(i % 5 == 0) {
				printWord = "Buzz";
			}
			//3でも５でも割れない場合、数字を文字列として代入
			else {
				printWord = printWord + i ;
				
			}
		//判別結果を出力
		System.out.println(printWord);	
		
		}
		
		

	}

}

package q2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * q1で作成した問題を仕様変更する
 * ・３，５と決まった数値でなくコンソールから入力した任意の倍数で割り切れる時にFizz、Buzz（両方の数値で割り切れる場合はFizzBuzz）と出力されるようにする
 * ・割り切れるかどうかの判定はboolean型を返すメソッドとして定義する
 * 例　isMultipleOf(int input,int count)
 * ※print文は複数回使ってよい。
 * ※例外処理は考慮しなくてよい
 * */
public class FizzBuzzMain {

	/**
	 * @param args メインメソッドの引数
	 * @throws NumberFormatException　型違いの例外処理
	 * @throws IOException　例外処理
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		//入力準備
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//変数宣言
		int inputNum1;
		int inputNum2;
		//最初の数字を入力
		System.out.print("input first multiple>>");
		String input1 = br.readLine();
		inputNum1 = Integer.parseInt(input1);
		//２番目の数字を入力
		System.out.print("input second multiple>>");
		String input2 = br.readLine();
		inputNum2 = Integer.parseInt(input2);
		
		//1-100を繰り返す
				//割り切れるか判別し数字か文字列を出力する
				for(int i = 1; i < 101 ;i++) {
					//文字列の初期化
					String printWord ="";
					//最初と２番目の両方で割れる場合、FizzBuuzを代入
					if(isMultipleOf(inputNum1 , i) && isMultipleOf(inputNum2 , i)) {
						printWord = "FizzBuzz";
					}
					//最初の数字で割れる場合、Fizzzを代入
					else if(isMultipleOf(inputNum1 , i)) {
						printWord = "Fizz";
					}
					//２番目の数字で割れる場合、Buuzを代入
					else if(isMultipleOf(inputNum2 , i)) {
						printWord = "Buzz";
					}
					//どちらでも割れない場合、数字を文字列として代入
					else {
						printWord = printWord + i ;
						
					}
				//判別結果を出力
				System.out.println(printWord);	
				}
	}

	/*
	 * 割り切れるか判別しboolean型で返すためのメソッド
	 */
	public static boolean isMultipleOf(int input, int count) {
		//変数の初期化
		boolean isMultiple = false;
		//入力値で割り切れる場合trueを返す
		if(count % input == 0) {
			isMultiple = true;
		}
		
		return isMultiple;
	}

}

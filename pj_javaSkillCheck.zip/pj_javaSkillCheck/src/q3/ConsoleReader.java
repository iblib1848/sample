package q3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * ConsoleReaderクラス
 */
public class ConsoleReader {
	//privateなので他のクラスから呼び出せない
	private ConsoleReader() {
	}

	/**
	 * 整数をコンソール入力して戻す
	 * 整数値以外を入力した場合は再度入力させる
	 * 
	 * @return コンソールから入力した整数を戻す
	 * @inputString String型の入力値
	 * @inputNumber int型の入力値
	 * 
	 */
	
	public Integer input() {
		//入力値を入れるための変数の宣言
		String inputString = null;
		Integer inputNumber = null;
		//入力準備
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//whileのための変数宣言
		
		boolean isValid = false;
		while (!isValid) {

			System.out.print("input multiple[1-10]>>");
			try {
				inputString = br.readLine();
				inputNumber = Integer.parseInt(inputString);
				if (inputNumber < 1 || 10 < inputNumber) {
					System.out.println("1～10の整数を入力してください");
					continue;
				}
				isValid = true;
			} catch (IOException e) {
				System.out.println("System Error");
				e.printStackTrace();
			} catch (NumberFormatException e) {
				System.out.println("整数を入力してください");
				continue;

			}
		}

		return inputNumber;

	}
	/*
	 * staticなので、インスタンス化しなくて使える
	 * ConsoleReaderクラスをインスタンス化するメソッド
	 */
	
	public static ConsoleReader getInstance() {
		return new ConsoleReader();
	}

}

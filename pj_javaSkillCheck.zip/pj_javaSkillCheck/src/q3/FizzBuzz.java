package q3;
/*
 * FizzBuzzクラス
 * 基本的な処理はここで行う
 */
public class FizzBuzz {

	private static final String MSG_FIRST_MULTIPLE = "最初の倍数を入力してください";
	private static final String MSG_SECOND_MULTIPLE = "次の倍数を入力してください";
	private static final int FIZZBUZZ_START_NUMBER = 1;
	private static final int FIZZBUZZ_END_NUMBER = 100;
	private static final String BUZZ = "Buzz";
	private static final String FIZZ = "Fizz";
	private static final String FIZZ_BUZZ = "FizzBuzz";
	private static String HYPHEN = "-------------------------------";

	/**{firsr}{second}をリプレイスしてメッセージ出力する*/
	private String msg_MultipeString = "{first}の倍数と{second}の倍数,両方の条件を満たす場合はメッセージが変わります。";

	/**
	 * ConsoleReaderインスタンスを生成し、コンソールから整数を2つ出力する。
	 * replaceMultipleメソッドを呼び出し、msg_MultipeStringをリプレイスして出力する。
	 * 入力した整数の倍数を使い、FizzBuzzルールに従い、文字列を出力する
	 * 
	 */
	public void start() {
		//ConsoleReader インスタンスの生成。staticなのでそのまま使えます
		//ConsoleReader consoleReader =new ConsoleReader();はコンストラクタがprivateなので使えなかった
		ConsoleReader consoleReader =ConsoleReader.getInstance();
		//変数宣言
		int inputNum1;
		int inputNum2;
		//最初の数字を入力させる
		System.out.println(MSG_FIRST_MULTIPLE);
		inputNum1 =consoleReader.input();		
		
		//次の数字を入力させる
		System.out.println(MSG_SECOND_MULTIPLE);
		inputNum2 =consoleReader.input();
		//msg_MultipeStringの{first}{second}を入力した値にリプレイスする
		replaceMultiple(inputNum1, inputNum2);
		
		System.out.println(msg_MultipeString);
		System.out.println(HYPHEN);
		
		//1-100を繰り返す
		//割り切れるか判別し数字か文字列を出力する
		for(int i =  FIZZBUZZ_START_NUMBER; i == FIZZBUZZ_END_NUMBER ;i++) {
			//文字列の初期化
			String printWord ="";
			//最初と２番目の両方で割れる場合、FizzBuuzを代入
			if(isMultipleOf(inputNum1 , i) && isMultipleOf(inputNum2 , i)) {
				printWord = FIZZ_BUZZ;
			}
			//最初の数字で割れる場合、Fizzzを代入
			else if(isMultipleOf(inputNum1 , i)) {
				printWord =FIZZ;
			}
			//２番目の数字で割れる場合、Buuzを代入
			else if(isMultipleOf(inputNum2 , i)) {
				printWord =BUZZ;
			}
			//どちらでも割れない場合、数字を文字列として代入
			else {
				printWord = printWord + i ;
				
			}
		//判別結果を出力
		System.out.println(printWord);	
		}
}
		
		
		
	
	

	/**
	 * msg_MultipeStringの{first}{second}を入力した値にリプレイスする
	 * 
	 * @param firstMultiple 最初に入力した数値
	 * @param secondMultiple 次に入力した数値
	 */
	private void replaceMultiple(Integer firstMultiple, Integer secondMultiple) {
		this.msg_MultipeString = this.msg_MultipeString.replace("{first}", String.valueOf(firstMultiple)).replace(
				"{second}",
				String.valueOf(secondMultiple));

	}

	/**
	 * 入力が指定の倍数であるかどうかを判定する
	 * @return true:倍数であるとき | false:倍数でないとき
	 * 
	 * */
	private boolean isMultipleOf(int input, int count) {

		boolean isMultiple = false;
		if (count % input == 0) {
			isMultiple = true;
		}
		return isMultiple;
	}

}

package q3;

/*
 * Mainクラス
 * 呼び出すのみ
 */
public class Main {

	/**
	 * @param args メインメソッドの変数
	 */
	public static void main(String[] args) {
		//導入文を出力
		System.out.println("FizzBuzz問題を出力します");
		//FizzBuzzクラス型のオブジェクトを生成し、startメソッドを呼び出す
		FizzBuzz fizzBuzz = new FizzBuzz();
		fizzBuzz.start();

	}

}

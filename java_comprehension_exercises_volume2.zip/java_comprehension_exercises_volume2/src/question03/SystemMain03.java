package question03;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SystemMain03 {

	public static void main(String[] args) throws IOException {
	
		Student studentA = new Student();
		System.out.println("StudentAの名前を入力してください。");
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String name = reader.readLine();
		studentA.setName(name);
		System.out.println("StudentAの年齢を入力してください。");
		String inputAge = reader.readLine();
		int age = Integer.parseInt(inputAge);
		studentA.setAge(age);
		
		Student studentB = new Student("山田",55);
		
		System.out.println("StudentAの名前は"+studentA.getName()+"、年齢は"+studentA.getAge()+"歳です。");
		System.out.println("StudentBの名前は"+studentB.getName()+"、年齢は"+studentB.getAge()+"歳です。");
		System.out.println("Studentクラスで生成したオブジェクトの数は"+ Student.totalStudent +"です。");
		
		Teacher teacherA = new Teacher();
		System.out.println("teacherAの名前を入力してください。");
		String teachername = reader.readLine();
		System.out.println("teacherAの年齢を入力してください。");
		int teacherAge = Integer.parseInt(reader.readLine());
		System.out.println("teacherAの住所を入力してください。");
		String teacherAddress = reader.readLine();
		teacherA.setTeacherInfo(teachername, teacherAge, teacherAddress);
		System.out.println("teacherAの住所は"+ teacherA.getAddress() +"入力してください。");
		
	}

}

class Student{
	
	private String name;
	private int age;
	static int totalStudent;
	
	
	Student(){
		totalStudent++;
	}
	Student(String name,int age){
		this();
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}

class Teacher{
	String name;
	int age;
	String address;
	
	
	void setTeacherInfo(String name) {
		this.name = name;
	}
	
	void setTeacherInfo(String name,int age) {
		this.name = name;
		this.age = age;
	}



	void setTeacherInfo(String name,int age,String address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}
	String getAddress() {
		return address;
	}
}

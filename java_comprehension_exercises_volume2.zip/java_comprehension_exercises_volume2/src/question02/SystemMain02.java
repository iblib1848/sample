package question02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//【第 14 章 メソッドの基本】
public class SystemMain02 {

	public static void main(String[] args)throws IOException {
		Member02 memberA = new Member02();
		memberA.name = "田中";
		memberA.age = 20;
		memberA.authority = 1;
		memberA.coupon =new int[2];
		memberA.show();
		
		Member02 memberB = new Member02();
		Administrator02 adminA = new Administrator02();
		adminA.password = 123;
		adminA.member02 = memberB;
		
		adminA.member02.name = "加藤";
		adminA.member02.age = 30;
		adminA.member02.authority = 2;
		adminA.member02.coupon = new int[5];
		adminA.changePass(456);
		
		System.out.println("会員情報を変更します。");
		System.out.println("名前を入力してください");
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String name = reader.readLine();
		System.out.println("年齢を入力してください");
		int age =Integer.parseInt(reader.readLine());
		adminA.changeStatus(name, age);
		adminA.show();
		adminA.showCoupon(memberA);
		adminA.showCoupon(memberB);
		
		System.out.println(memberA.name+"さんの権限を確認します。");
		int authority = memberA.confirmation();
		if(authority == 1) {
			System.out.println("権限は一般会員です。");
		}else if(authority == 2) {
			System.out.println("権限は管理者です。");
		}else {
			System.out.println("権限は登録されていません。");
		}
		int[] newCoupon =memberA.changeCoupon(7);
		System.out.println("クーポンの数は"+ newCoupon.length+ "個です。");
	}

}

class Member02{
	String name;
	int age;
	int authority;
	int[] coupon;
	
	void show() {
		this.introduction();
		System.out.println("名前は"+name +"です。");
		System.out.println("年齢は"+age +"歳です。");
	}
	void introduction() {
		System.out.println("会員の簡単な自己紹介をします");
	}
	int confirmation() {
	return authority;
	}
	int[] changeCoupon(int number) {
		System.out.println("クーポンの数を変更します。");
		coupon = new int[number];
		return coupon;
	}
	
}

class Administrator02{
	
	int password;
	Member02 member02 = new Member02();
	
	void changePass(int pass) {
		System.out.println("パスワードを変更します。");
		this.password = pass;
		System.out.println("パスワードは"+ password+"です。");
	}
	
	void changeStatus(String changeName,int changeAge) {
		System.out.println("会員情報を変更します。");
		member02.name =  changeName;
		member02.age = changeAge;
	}
	void show() {
		System.out.println("名前は"+member02.name+"です。");
		System.out.println("年齢は"+member02.age+"です。");
	}
	void showCoupon(Member02 member02) {
		System.out.println(member02.name + "さんのクーポンの数を表示します。");
		System.out.println("クーポンの数は"+member02.coupon.length+"個です。");
	}
	
}


